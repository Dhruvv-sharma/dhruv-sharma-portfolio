import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, Mail, MapPin, Send } from "lucide-react";
import SectionHeading from "./SectionHeading";

const initialForm = { name: "", email: "", message: "" };

export default function Contact() {
  const [form, setForm] = useState(initialForm);
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setStatus("");
    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      if (!response.ok) throw new Error("Could not send message");
      setForm(initialForm);
      setStatus("Message sent. I’ll get back to you soon.");
    } catch {
      setStatus("The API is offline. Please email me directly for now.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="section section-tinted" id="contact">
      <div className="section-shell">
        <SectionHeading eyebrow="06 / Contact" title="Let’s make something meaningful." />
        <div className="contact-grid">
          <motion.div
            className="contact-copy"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <p>
              Have an opportunity, a project idea, or just want to talk about technology?
              My inbox is open.
            </p>
            <a href="mailto:dhruv.sharma@example.com">
              <span><Mail /></span>
              <div><small>Email me</small>dhruv.sharma@example.com</div>
              <ArrowUpRight />
            </a>
            <div className="contact-location">
              <span><MapPin /></span>
              <div><small>Based in</small>India · Open to remote</div>
            </div>
          </motion.div>
          <motion.form
            className="contact-form glass-card"
            onSubmit={submit}
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <label>
              Your name
              <input
                required
                value={form.name}
                onChange={(event) => setForm({ ...form, name: event.target.value })}
                placeholder="John Doe"
              />
            </label>
            <label>
              Email address
              <input
                required
                type="email"
                value={form.email}
                onChange={(event) => setForm({ ...form, email: event.target.value })}
                placeholder="john@example.com"
              />
            </label>
            <label>
              Your message
              <textarea
                required
                rows="5"
                value={form.message}
                onChange={(event) => setForm({ ...form, message: event.target.value })}
                placeholder="Tell me about your idea..."
              />
            </label>
            <button className="button button-primary" disabled={loading}>
              {loading ? "Sending..." : "Send message"} <Send size={17} />
            </button>
            {status && <p className="form-status">{status}</p>}
          </motion.form>
        </div>
      </div>
    </section>
  );
}
