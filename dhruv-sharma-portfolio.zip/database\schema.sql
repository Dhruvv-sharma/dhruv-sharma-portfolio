CREATE DATABASE IF NOT EXISTS portfolio
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE portfolio;

CREATE TABLE IF NOT EXISTS projects (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(160) NOT NULL,
  description TEXT NOT NULL,
  tech_stack VARCHAR(500) NOT NULL,
  github_link VARCHAR(500) NOT NULL,
  live_link VARCHAR(500) NULL,
  image VARCHAR(1000) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS contacts (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_contacts_created_at (created_at)
);

CREATE TABLE IF NOT EXISTS visitor_counter (
  id TINYINT UNSIGNED NOT NULL,
  count BIGINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
);

INSERT INTO visitor_counter (id, count)
VALUES (1, 0)
ON DUPLICATE KEY UPDATE id = id;

INSERT INTO projects (title, description, tech_stack, github_link, live_link, image)
SELECT
  'Personal Portfolio Website',
  'A polished developer portfolio with animated sections, a project CMS, contact workflow, and performance-first responsive design.',
  'React.js, Node.js, Express, MySQL',
  'https://github.com/',
  '',
  ''
WHERE NOT EXISTS (
  SELECT 1 FROM projects WHERE title = 'Personal Portfolio Website'
);

INSERT INTO projects (title, description, tech_stack, github_link, live_link, image)
SELECT
  'Student Management System',
  'A full-stack dashboard for managing student records, attendance, courses, and reports with role-ready CRUD workflows.',
  'React.js, Node.js, MySQL',
  'https://github.com/',
  '',
  ''
WHERE NOT EXISTS (
  SELECT 1 FROM projects WHERE title = 'Student Management System'
);
