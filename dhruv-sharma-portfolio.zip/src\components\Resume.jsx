import { motion } from "framer-motion";
import { Download, FileText } from "lucide-react";

export default function Resume() {
  return (
    <section className="section section-shell" id="resume">
      <motion.div
        className="resume-banner"
        initial={{ opacity: 0, scale: 0.97 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
      >
        <div className="resume-icon"><FileText /></div>
        <div>
          <span>Want the complete picture?</span>
          <h2>Experience, education, and everything in between.</h2>
        </div>
        <a className="button button-light" href="/resume-placeholder.txt" download>
          Download resume <Download size={18} />
        </a>
      </motion.div>
    </section>
  );
}
