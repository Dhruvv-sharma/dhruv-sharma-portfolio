import { motion } from "framer-motion";
import { ArrowUpRight, CodeXml, Github, Trophy } from "lucide-react";
import SectionHeading from "./SectionHeading";

export default function CodingProfiles() {
  return (
    <section className="section section-shell" id="profiles">
      <SectionHeading
        eyebrow="05 / Beyond the editor"
        title="Practice. Ship. Repeat."
        description="Coding profiles that reflect consistent problem solving and public work."
      />
      <div className="profile-grid">
        <motion.a
          className="profile-card github-profile"
          href="https://github.com/"
          target="_blank"
          rel="noreferrer"
          whileHover={{ y: -7 }}
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <div className="profile-top"><Github /><ArrowUpRight /></div>
          <span>GitHub</span>
          <h3>Building in public.</h3>
          <div className="contribution-grid">
            {Array.from({ length: 70 }, (_, index) => <i key={index} style={{ opacity: 0.15 + ((index * 7) % 8) / 10 }} />)}
          </div>
          <small>Repositories, experiments, and open-source learning.</small>
        </motion.a>
        <motion.a
          className="profile-card leetcode-profile"
          href="https://leetcode.com/"
          target="_blank"
          rel="noreferrer"
          whileHover={{ y: -7 }}
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.12 }}
        >
          <div className="profile-top"><CodeXml /><ArrowUpRight /></div>
          <span>LeetCode</span>
          <h3>Sharpening the fundamentals.</h3>
          <div className="leetcode-stats">
            <div className="score-ring"><strong>150+</strong><span>Solved</span></div>
            <div>
              <p><i className="easy" /> Easy <strong>82</strong></p>
              <p><i className="medium" /> Medium <strong>61</strong></p>
              <p><i className="hard" /> Hard <strong>07</strong></p>
            </div>
          </div>
          <small><Trophy size={14} /> Consistency over intensity.</small>
        </motion.a>
      </div>
    </section>
  );
}
