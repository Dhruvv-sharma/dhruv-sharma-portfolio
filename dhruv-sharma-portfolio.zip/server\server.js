import express from "express";
import cors from "cors";
import "dotenv/config";
import { pool } from "./db.js";

const app = express();
const port = Number(process.env.PORT || 5000);

app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173" }));
app.use(express.json({ limit: "1mb" }));

const asyncRoute = (handler) => (request, response, next) =>
  Promise.resolve(handler(request, response, next)).catch(next);

const requireAdmin = (request, response, next) => {
  const configuredKey = process.env.ADMIN_KEY;
  if (!configuredKey) {
    return response.status(503).json({ message: "ADMIN_KEY is not configured." });
  }
  if (request.get("x-admin-key") !== configuredKey) {
    return response.status(401).json({ message: "Invalid admin key." });
  }
  next();
};

const validUrl = (value, optional = false) => {
  if (!value && optional) return true;
  try {
    const url = new URL(value);
    return ["http:", "https:"].includes(url.protocol);
  } catch {
    return false;
  }
};

const validateProject = (project) => {
  const required = ["title", "description", "tech_stack", "github_link"];
  if (required.some((field) => typeof project[field] !== "string" || !project[field].trim())) {
    return "Title, description, tech stack, and GitHub link are required.";
  }
  if (!validUrl(project.github_link)) return "GitHub link must be a valid URL.";
  if (!validUrl(project.live_link, true)) return "Live link must be a valid URL.";
  if (!validUrl(project.image, true)) return "Image must be a valid URL.";
  return null;
};

app.get("/api/health", asyncRoute(async (_request, response) => {
  await pool.query("SELECT 1");
  response.json({ status: "ok" });
}));

app.get("/api/projects", asyncRoute(async (_request, response) => {
  const [rows] = await pool.query(
    "SELECT id, title, description, tech_stack, github_link, live_link, image, created_at, updated_at FROM projects ORDER BY id DESC"
  );
  response.json(rows);
}));

app.post("/api/projects", requireAdmin, asyncRoute(async (request, response) => {
  const error = validateProject(request.body);
  if (error) return response.status(400).json({ message: error });

  const { title, description, tech_stack, github_link, live_link = "", image = "" } = request.body;
  const [result] = await pool.execute(
    `INSERT INTO projects (title, description, tech_stack, github_link, live_link, image)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [title.trim(), description.trim(), tech_stack.trim(), github_link.trim(), live_link.trim(), image.trim()]
  );
  const [rows] = await pool.execute("SELECT * FROM projects WHERE id = ?", [result.insertId]);
  response.status(201).json(rows[0]);
}));

app.put("/api/projects/:id", requireAdmin, asyncRoute(async (request, response) => {
  const error = validateProject(request.body);
  if (error) return response.status(400).json({ message: error });

  const { title, description, tech_stack, github_link, live_link = "", image = "" } = request.body;
  const [result] = await pool.execute(
    `UPDATE projects
     SET title = ?, description = ?, tech_stack = ?, github_link = ?, live_link = ?, image = ?
     WHERE id = ?`,
    [title.trim(), description.trim(), tech_stack.trim(), github_link.trim(), live_link.trim(), image.trim(), request.params.id]
  );
  if (!result.affectedRows) return response.status(404).json({ message: "Project not found." });
  const [rows] = await pool.execute("SELECT * FROM projects WHERE id = ?", [request.params.id]);
  response.json(rows[0]);
}));

app.delete("/api/projects/:id", requireAdmin, asyncRoute(async (request, response) => {
  const [result] = await pool.execute("DELETE FROM projects WHERE id = ?", [request.params.id]);
  if (!result.affectedRows) return response.status(404).json({ message: "Project not found." });
  response.status(204).send();
}));

app.post("/api/contact", asyncRoute(async (request, response) => {
  const { name, email, message } = request.body;
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (![name, email, message].every((value) => typeof value === "string" && value.trim())) {
    return response.status(400).json({ message: "Name, email, and message are required." });
  }
  if (!emailPattern.test(email) || email.length > 190) {
    return response.status(400).json({ message: "Please provide a valid email address." });
  }
  if (name.length > 120 || message.length > 5000) {
    return response.status(400).json({ message: "Contact message is too long." });
  }

  const [result] = await pool.execute(
    "INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)",
    [name.trim(), email.trim().toLowerCase(), message.trim()]
  );
  response.status(201).json({ id: result.insertId, message: "Message received." });
}));

app.get("/api/contacts", requireAdmin, asyncRoute(async (_request, response) => {
  const [rows] = await pool.query(
    "SELECT id, name, email, message, created_at FROM contacts ORDER BY created_at DESC"
  );
  response.json(rows);
}));

app.post("/api/visitors", asyncRoute(async (_request, response) => {
  await pool.query("UPDATE visitor_counter SET count = LAST_INSERT_ID(count + 1) WHERE id = 1");
  const [rows] = await pool.query("SELECT count FROM visitor_counter WHERE id = 1");
  response.json({ count: rows[0].count });
}));

app.use((error, _request, response, _next) => {
  console.error(error);
  const databaseOffline = ["ECONNREFUSED", "ER_BAD_DB_ERROR", "ER_ACCESS_DENIED_ERROR"].includes(error.code);
  response.status(databaseOffline ? 503 : 500).json({
    message: databaseOffline ? "Database is unavailable. Check the MySQL configuration." : "Unexpected server error."
  });
});

app.listen(port, () => {
  console.log(`Portfolio API running at http://localhost:${port}`);
});
