import { useEffect, useState } from "react";
import { ArrowLeft, Edit3, Inbox, LayoutDashboard, Plus, Trash2, X } from "lucide-react";

const emptyProject = {
  title: "",
  description: "",
  tech_stack: "",
  github_link: "",
  live_link: "",
  image: ""
};

export default function AdminDashboard() {
  const [projects, setProjects] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [form, setForm] = useState(emptyProject);
  const [editingId, setEditingId] = useState(null);
  const [adminKey, setAdminKey] = useState(sessionStorage.getItem("portfolio-admin-key") || "");
  const [notice, setNotice] = useState("");

  const headers = {
    "Content-Type": "application/json",
    "x-admin-key": adminKey
  };

  const load = async () => {
    try {
      const [projectResponse, contactResponse] = await Promise.all([
        fetch("/api/projects"),
        fetch("/api/contacts", { headers: { "x-admin-key": adminKey } })
      ]);
      setProjects(await projectResponse.json());
      if (contactResponse.ok) setContacts(await contactResponse.json());
    } catch {
      setNotice("Start the API server to manage portfolio data.");
    }
  };

  useEffect(() => { load(); }, []);

  const save = async (event) => {
    event.preventDefault();
    sessionStorage.setItem("portfolio-admin-key", adminKey);
    const url = editingId ? `/api/projects/${editingId}` : "/api/projects";
    const response = await fetch(url, {
      method: editingId ? "PUT" : "POST",
      headers,
      body: JSON.stringify(form)
    });
    if (!response.ok) {
      setNotice("Could not save. Check the API and admin key.");
      return;
    }
    setForm(emptyProject);
    setEditingId(null);
    setNotice("Project saved.");
    load();
  };

  const edit = (project) => {
    setEditingId(project.id);
    setForm({
      title: project.title,
      description: project.description,
      tech_stack: project.tech_stack,
      github_link: project.github_link,
      live_link: project.live_link || "",
      image: project.image || ""
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const remove = async (id) => {
    if (!window.confirm("Delete this project?")) return;
    const response = await fetch(`/api/projects/${id}`, { method: "DELETE", headers });
    if (response.ok) load();
    else setNotice("Could not delete. Check your admin key.");
  };

  return (
    <main className="admin-shell">
      <header className="admin-header">
        <div><LayoutDashboard /><strong>Portfolio Admin</strong></div>
        <a href="#home"><ArrowLeft /> Back to portfolio</a>
      </header>
      <div className="admin-grid">
        <section className="admin-panel">
          <div className="admin-title">
            <div><Plus /><span>{editingId ? "Edit project" : "Add project"}</span></div>
            {editingId && <button onClick={() => { setEditingId(null); setForm(emptyProject); }}><X /></button>}
          </div>
          <form className="admin-form" onSubmit={save}>
            <label>Admin key<input type="password" value={adminKey} onChange={(e) => setAdminKey(e.target.value)} required /></label>
            <label>Title<input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required /></label>
            <label>Description<textarea rows="4" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} required /></label>
            <label>Tech stack<input value={form.tech_stack} onChange={(e) => setForm({ ...form, tech_stack: e.target.value })} placeholder="React.js, Node.js, MySQL" required /></label>
            <label>GitHub link<input type="url" value={form.github_link} onChange={(e) => setForm({ ...form, github_link: e.target.value })} required /></label>
            <label>Live link<input type="url" value={form.live_link} onChange={(e) => setForm({ ...form, live_link: e.target.value })} /></label>
            <label>Image URL<input type="url" value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} /></label>
            <button className="button button-primary">{editingId ? "Update project" : "Add project"}</button>
          </form>
          {notice && <p className="admin-notice">{notice}</p>}
        </section>
        <section className="admin-panel">
          <div className="admin-title"><div><LayoutDashboard /><span>Projects</span></div><small>{projects.length} total</small></div>
          <div className="admin-list">
            {projects.map((project) => (
              <article key={project.id}>
                <div><strong>{project.title}</strong><span>{project.tech_stack}</span></div>
                <button onClick={() => edit(project)} aria-label="Edit project"><Edit3 /></button>
                <button className="danger" onClick={() => remove(project.id)} aria-label="Delete project"><Trash2 /></button>
              </article>
            ))}
          </div>
        </section>
        <section className="admin-panel admin-messages">
          <div className="admin-title"><div><Inbox /><span>Contact messages</span></div><small>{contacts.length} total</small></div>
          <div className="message-grid">
            {contacts.map((contact) => (
              <article key={contact.id}>
                <span>{contact.name} · {contact.email}</span>
                <p>{contact.message}</p>
                <small>{new Date(contact.created_at).toLocaleDateString()}</small>
              </article>
            ))}
            {!contacts.length && <p className="empty-state">No messages loaded. Enter the admin key and save or refresh.</p>}
          </div>
        </section>
      </div>
    </main>
  );
}
