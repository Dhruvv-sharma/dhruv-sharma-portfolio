import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowDown, ArrowUpRight, Github, Linkedin } from "lucide-react";

const words = ["Full Stack Developer", "React Enthusiast", "Problem Solver"];

export default function Hero() {
  const [text, setText] = useState("");
  const [wordIndex, setWordIndex] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const word = words[wordIndex];
    const delay = deleting ? 45 : 85;
    const timer = setTimeout(() => {
      if (!deleting && text === word) {
        setTimeout(() => setDeleting(true), 1000);
      } else if (deleting && text === "") {
        setDeleting(false);
        setWordIndex((index) => (index + 1) % words.length);
      } else {
        setText(word.slice(0, text.length + (deleting ? -1 : 1)));
      }
    }, delay);
    return () => clearTimeout(timer);
  }, [text, deleting, wordIndex]);

  return (
    <section className="hero section-shell" id="home">
      <motion.div
        className="hero-copy"
        initial={{ opacity: 0, x: -40 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.8 }}
      >
        <div className="availability"><span /> Available for opportunities</div>
        <p className="hero-kicker">Hello, I&apos;m</p>
        <h1>Dhruv <span>Sharma.</span></h1>
        <div className="typing-line">
          I&apos;m a <strong>{text}</strong><i />
        </div>
        <p className="hero-intro">
          I build thoughtful, scalable digital experiences where clean code meets
          intuitive design. Currently turning ideas into real-world products with
          React, Node.js, and MySQL.
        </p>
        <div className="hero-actions">
          <a className="button button-primary" href="#projects">
            View my work <ArrowUpRight size={18} />
          </a>
          <a className="button button-secondary" href="/resume-placeholder.txt" download>
            Download resume <ArrowDown size={18} />
          </a>
        </div>
        <div className="hero-socials">
          <a href="https://github.com/" target="_blank" rel="noreferrer" aria-label="GitHub">
            <Github size={19} />
          </a>
          <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" aria-label="LinkedIn">
            <Linkedin size={19} />
          </a>
          <span>Follow my journey</span>
        </div>
      </motion.div>

      <motion.div
        className="hero-visual"
        initial={{ opacity: 0, scale: 0.9, x: 40 }}
        animate={{ opacity: 1, scale: 1, x: 0 }}
        transition={{ duration: 0.9, delay: 0.15 }}
      >
        <div className="orbit orbit-one" />
        <div className="orbit orbit-two" />
        <div className="portrait-frame">
          <img src="/assets/dhruv-developer.png" alt="Illustrated developer portrait" />
          <div className="portrait-shine" />
        </div>
        <motion.div
          className="floating-card code-card"
          animate={{ y: [0, -9, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        >
          <span className="window-dots"><i /><i /><i /></span>
          <code><b>const</b> developer = {"{"}</code>
          <code>&nbsp;&nbsp;name: <em>&apos;Dhruv&apos;</em>,</code>
          <code>&nbsp;&nbsp;passion: <em>&apos;build&apos;</em></code>
          <code>{"}"}</code>
        </motion.div>
        <motion.div
          className="floating-card stack-card"
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut" }}
        >
          <strong>2+</strong>
          <span>Years of learning</span>
        </motion.div>
      </motion.div>
      <a className="scroll-cue" href="#about"><span /> Scroll to explore</a>
    </section>
  );
}
