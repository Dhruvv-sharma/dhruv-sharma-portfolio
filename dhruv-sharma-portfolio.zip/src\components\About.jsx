import { motion } from "framer-motion";
import { Braces, GraduationCap, Lightbulb, Target } from "lucide-react";
import SectionHeading from "./SectionHeading";

const facts = [
  { icon: GraduationCap, value: "MCA", label: "Student" },
  { icon: Braces, value: "Full Stack", label: "Focus" },
  { icon: Lightbulb, value: "Always", label: "Learning" }
];

export default function About() {
  return (
    <section className="section-shell section" id="about">
      <SectionHeading eyebrow="01 / About" title="Curious by nature. Driven by craft." />
      <div className="about-grid">
        <motion.div
          className="about-story"
          initial={{ opacity: 0, x: -35 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <p className="large-copy">
            I&apos;m an MCA student and aspiring full stack developer who enjoys
            transforming complex problems into <span>simple, useful products.</span>
          </p>
          <p>
            My work sits at the intersection of engineering and experience design. I
            care about maintainable systems, polished interfaces, and the small details
            that make software feel effortless.
          </p>
          <p>
            My goal is to grow into an engineer who can own products end to end, while
            contributing to teams that value curiosity, clarity, and real user impact.
          </p>
          <div className="goal-line">
            <Target size={20} />
            <span>Currently focused on scalable React patterns and backend architecture.</span>
          </div>
        </motion.div>
        <div className="fact-grid">
          {facts.map(({ icon: Icon, value, label }, index) => (
            <motion.div
              className="glass-card fact-card"
              key={value}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -6 }}
            >
              <Icon />
              <strong>{value}</strong>
              <span>{label}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
