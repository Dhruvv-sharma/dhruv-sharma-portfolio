import { motion } from "framer-motion";
import { Code2, Database, Server, Wrench } from "lucide-react";
import SectionHeading from "./SectionHeading";

const groups = [
  { title: "Frontend", icon: Code2, skills: ["HTML", "CSS", "JavaScript", "React.js"] },
  { title: "Backend", icon: Server, skills: ["Node.js", "Express.js", "REST APIs"] },
  { title: "Database", icon: Database, skills: ["MySQL", "Data Modeling", "SQL"] },
  { title: "Tools", icon: Wrench, skills: ["Git", "GitHub", "VS Code"] }
];

export default function Skills() {
  return (
    <section className="section section-tinted" id="skills">
      <div className="section-shell">
        <SectionHeading
          eyebrow="02 / Skills"
          title="The tools behind the work."
          description="A focused toolkit for building reliable products from interface to database."
        />
        <div className="skills-grid">
          {groups.map(({ title, icon: Icon, skills }, index) => (
            <motion.article
              className="glass-card skill-card"
              key={title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ delay: index * 0.08 }}
              whileHover={{ y: -8 }}
            >
              <div className="skill-icon"><Icon /></div>
              <span className="skill-number">0{index + 1}</span>
              <h3>{title}</h3>
              <div className="skill-tags">
                {skills.map((skill) => <span key={skill}>{skill}</span>)}
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
