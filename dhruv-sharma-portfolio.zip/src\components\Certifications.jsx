import { motion } from "framer-motion";
import { Award, ExternalLink } from "lucide-react";
import SectionHeading from "./SectionHeading";
import { certificates } from "../data";

export default function Certifications() {
  return (
    <section className="section section-tinted" id="certifications">
      <div className="section-shell">
        <SectionHeading
          eyebrow="04 / Certifications"
          title="Learning, made visible."
          description="Milestones from an ongoing commitment to technical depth and practical growth."
        />
        <div className="cert-grid">
          {certificates.map((certificate, index) => (
            <motion.article
              className="glass-card cert-card"
              key={certificate.title}
              initial={{ opacity: 0, x: index % 2 ? 25 : -25 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.08 }}
            >
              <div className="cert-mark">{certificate.code}</div>
              <div>
                <span>{certificate.issuer}</span>
                <h3>{certificate.title}</h3>
                <small>{certificate.year}</small>
              </div>
              <Award className="cert-award" />
              <button aria-label={`View ${certificate.title}`}>
                <ExternalLink size={17} />
              </button>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
