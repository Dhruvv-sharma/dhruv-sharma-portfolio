import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, Github } from "lucide-react";
import SectionHeading from "./SectionHeading";
import ProjectVisual from "./ProjectVisual";
import { fallbackProjects } from "../data";

export default function Projects() {
  const [projects, setProjects] = useState(fallbackProjects);
  const [filter, setFilter] = useState("All");

  useEffect(() => {
    fetch("/api/projects")
      .then((response) => {
        if (!response.ok) throw new Error("API unavailable");
        return response.json();
      })
      .then((data) => data.length && setProjects(data))
      .catch(() => {});
  }, []);

  const filters = useMemo(() => {
    const stack = projects.flatMap((project) => project.tech_stack.split(",").map((item) => item.trim()));
    return ["All", ...new Set(stack.filter((item) => ["React.js", "Node.js", "MySQL"].includes(item)))];
  }, [projects]);

  const visible = filter === "All"
    ? projects
    : projects.filter((project) => project.tech_stack.includes(filter));

  return (
    <section className="section section-shell" id="projects">
      <div className="heading-row">
        <SectionHeading
          eyebrow="03 / Selected work"
          title="Projects with purpose."
          description="A selection of products built to solve practical problems and sharpen the craft."
        />
        <div className="project-filters" aria-label="Filter projects">
          {filters.map((item) => (
            <button
              className={filter === item ? "active" : ""}
              key={item}
              onClick={() => setFilter(item)}
            >
              {item}
            </button>
          ))}
        </div>
      </div>
      <motion.div className="projects-grid" layout>
        {visible.map((project, index) => (
          <motion.article
            className="project-card"
            key={project.id}
            layout
            initial={{ opacity: 0, y: 35 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ y: -8 }}
          >
            <ProjectVisual
              type={project.accent || (index % 2 ? "blue" : "violet")}
              image={project.image}
              title={project.title}
            />
            <div className="project-body">
              <div className="project-index">0{index + 1}</div>
              <h3>{project.title}</h3>
              <p>{project.description}</p>
              <div className="project-stack">
                {project.tech_stack.split(",").map((tech) => <span key={tech}>{tech.trim()}</span>)}
              </div>
              <div className="project-links">
                <a href={project.github_link} target="_blank" rel="noreferrer">
                  <Github size={18} /> Code
                </a>
                <a href={project.live_link || "#"} target="_blank" rel="noreferrer">
                  Live demo <ArrowUpRight size={18} />
                </a>
              </div>
            </div>
          </motion.article>
        ))}
      </motion.div>
    </section>
  );
}
