import { useEffect, useState } from "react";
import { ArrowUp, Github, Linkedin } from "lucide-react";

export default function Footer() {
  const [visitors, setVisitors] = useState(null);

  useEffect(() => {
    fetch("/api/visitors", { method: "POST" })
      .then((response) => response.json())
      .then((data) => setVisitors(data.count))
      .catch(() => {
        const count = Number(localStorage.getItem("portfolio-visits") || 0) + 1;
        localStorage.setItem("portfolio-visits", String(count));
        setVisitors(count);
      });
  }, []);

  return (
    <footer className="footer section-shell">
      <a className="brand" href="#home">DS<span>.</span></a>
      <p>Designed and built with intention by Dhruv Sharma.</p>
      <div className="footer-right">
        {visitors !== null && <small>{visitors.toLocaleString()} visits</small>}
        <a href="https://github.com/" target="_blank" rel="noreferrer" aria-label="GitHub"><Github /></a>
        <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" aria-label="LinkedIn"><Linkedin /></a>
        <a href="#home" aria-label="Back to top"><ArrowUp /></a>
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} Dhruv Sharma. All rights reserved.</span>
        <a href="#admin">Admin</a>
      </div>
    </footer>
  );
}
