export const fallbackProjects = [
  {
    id: 1,
    title: "Personal Portfolio Website",
    description:
      "A polished developer portfolio with animated sections, a project CMS, contact workflow, and performance-first responsive design.",
    tech_stack: "React.js, Node.js, Express, MySQL",
    github_link: "https://github.com/",
    live_link: "#",
    image: "",
    accent: "violet"
  },
  {
    id: 2,
    title: "Student Management System",
    description:
      "A full-stack dashboard for managing student records, attendance, courses, and reports with role-ready CRUD workflows.",
    tech_stack: "React.js, Node.js, MySQL",
    github_link: "https://github.com/",
    live_link: "#",
    image: "",
    accent: "blue"
  }
];

export const certificates = [
  {
    title: "Full Stack Web Development",
    issuer: "Professional Certification",
    year: "2025",
    code: "FS"
  },
  {
    title: "React.js Development",
    issuer: "Advanced Frontend Track",
    year: "2025",
    code: "RE"
  },
  {
    title: "Database Management",
    issuer: "MySQL Fundamentals",
    year: "2024",
    code: "DB"
  }
];
