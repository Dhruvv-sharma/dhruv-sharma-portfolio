import { Code2, Database, Layers3, Users } from "lucide-react";

export default function ProjectVisual({ type = "violet", image, title }) {
  if (image) {
    return <img className="project-image" src={image} alt={title} />;
  }

  if (type === "blue") {
    return (
      <div className="project-placeholder project-blue">
        <div className="mini-sidebar"><span /><span /><span /><span /></div>
        <div className="mini-content">
          <div className="mini-header"><strong>Students</strong><span>+ Add new</span></div>
          <div className="mini-stats">
            <i><Users />1,248</i><i><Layers3 />42</i><i><Database />98%</i>
          </div>
          <div className="mini-table"><span /><span /><span /><span /></div>
        </div>
      </div>
    );
  }

  return (
    <div className="project-placeholder project-violet">
      <div className="mini-browser">
        <div className="mini-browser-bar"><i /><i /><i /></div>
        <div className="mini-portfolio">
          <span>Hello, I&apos;m</span>
          <strong>Dhruv Sharma</strong>
          <small>Full Stack Developer</small>
          <i><Code2 /></i>
        </div>
      </div>
    </div>
  );
}
